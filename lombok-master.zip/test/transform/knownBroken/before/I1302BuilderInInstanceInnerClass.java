public class I1302BuilderInInstanceInnerClass {
  @lombok.Builder public class NonStaticInner {
    private int test;
  }
}
