class FieldDefaultsViaConfigAndRequiredArgsConstructor {
	final int x;
	@java.beans.ConstructorProperties({"x"})
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public FieldDefaultsViaConfigAndRequiredArgsConstructor(final int x) {
		this.x = x;
	}
}
