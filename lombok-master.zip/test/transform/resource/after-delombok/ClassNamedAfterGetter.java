class GetFoo {
	private int foo;
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public int getFoo() {
		return this.foo;
	}
}
