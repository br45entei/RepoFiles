class GetterNone {
	int i;
	int foo;
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public int getI() {
		return this.i;
	}
}
