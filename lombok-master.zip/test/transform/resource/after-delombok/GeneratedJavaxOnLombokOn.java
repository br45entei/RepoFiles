class GeneratedJavaxOnLombokOn {
	int x;
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	@lombok.Generated
	public int getX() {
		return this.x;
	}
}
