class EncodingUtf8 {
	String foo๑๑ = "\016\t\b ";
	@java.lang.Override
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public java.lang.String toString() {
		return "EncodingUtf8(foo๑๑=" + this.foo๑๑ + ")";
	}
}
