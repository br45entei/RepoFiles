class FieldDefaultsNoop {
}
