class ConstructorsConfiguration {
	int x;
	@java.lang.SuppressWarnings("all")
	@javax.annotation.Generated("lombok")
	public ConstructorsConfiguration(final int x) {
		this.x = x;
	}
}
