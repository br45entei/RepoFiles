class GeneratedJavaxOff {
	int x;
	@java.lang.SuppressWarnings("all")
	public int getX() {
		return this.x;
	}
}
