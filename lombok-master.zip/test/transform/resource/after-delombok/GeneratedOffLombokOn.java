class GeneratedOffLombokOn {
	int x;
	@java.lang.SuppressWarnings("all")
	@lombok.Generated
	public int getX() {
		return this.x;
	}
}
