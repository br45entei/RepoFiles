public interface Bar extends java.util.RandomAccess, java.util.Map {
	String getName();
}